webpackJsonp([110],{856:function(t,e,a){"use strict";function d(t,e,a,d){return o[t]}Object.defineProperty(e,"__esModule",{value:!0}),e.default=d;var o={lastWeek:"[last] dddd [at] LT",yesterday:"[yesterday at] LT",today:"[today at] LT",tomorrow:"[tomorrow at] LT",nextWeek:"dddd [at] LT",other:"L"};t.exports=e.default}});
//# sourceMappingURL=ba93b717f33e360a16dc.js.map
