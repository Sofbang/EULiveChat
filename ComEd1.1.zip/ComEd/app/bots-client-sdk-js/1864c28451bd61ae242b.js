webpackJsonp([185],{781:function(e,t,d){"use strict";function u(e,t,d,u){return r[e]}Object.defineProperty(t,"__esModule",{value:!0}),t.default=u;var r={lastWeek:"[letzten] dddd [um] LT",yesterday:"[gestern um] LT",today:"[heute um] LT",tomorrow:"[morgen um] LT",nextWeek:"dddd [um] LT",other:"L"};e.exports=t.default}});
//# sourceMappingURL=1864c28451bd61ae242b.js.map
