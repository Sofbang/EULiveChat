webpackJsonp([56],{911:function(e,M,Y){"use strict";Object.defineProperty(M,"__esModule",{value:!0});var t=Y(206),L=function(e){return e&&e.__esModule?e:{default:e}}(t),d=(0,L.default)({LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY р.",LLL:"D MMMM YYYY р., HH:mm",LLLL:"dddd, D MMMM YYYY р., HH:mm"});M.default=d,e.exports=M.default}});
//# sourceMappingURL=08c003bcd14fbc0e333c.js.map
